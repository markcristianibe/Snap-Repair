document.addEventListener('DOMContentLoaded', function(){
    $('.nav_link').removeClass('active');
    $('#dashboard').addClass('active');
});
